// pages/index/index.js
Page({
  data: {
    isLogin: false,
    userInfo: null,
    searchKeyword: '',
    searchResults: [],
    isSearching: false,
    categories: [
      { id: 'books', name: '图书' },
      { id: 'electronics', name: '电子产品' },
      { id: 'clothes', name: '服饰' },
      { id: 'sports', name: '运动器材' },
      { id: 'other', name: '其他' }
    ],
    selectedCategory: '',
    categoryMenuOpen: false,
    hasSearched: false,
    // 新增：排序模式与模拟商品数据
    sortMode: 'heat',
    mockProducts: [
      { id: 'p1', name: '二手教材 高等数学', description: '九成新，附赠笔记', price: 25, heat: 98, category: 'books', image: '/images/book1.png' },
      { id: 'p2', name: '二手手机 小米', description: '功能完好，轻微划痕', price: 699, heat: 230, category: 'electronics', image: '/images/phone1.png' },
      { id: 'p3', name: '运动球鞋', description: '八成新，舒适耐用', price: 120, heat: 150, category: 'sports', image: '/images/shoes1.png' },
      { id: 'p4', name: '保温杯', description: '几乎全新', price: 35, heat: 45, category: 'other', image: '/images/cup1.png' },
      { id: 'p5', name: '羽绒服', description: '保暖，尺码L', price: 260, heat: 80, category: 'clothes', image: '/images/coat1.png' }
    ]
  },

  onLoad: function(options) {
    // 页面加载时执行
    this.checkLoginStatus();
  },
  
  onShow: function() {
    // 页面显示时再次检查登录状态，确保状态同步
    this.checkLoginStatus();
  },

  // 检查登录状态
  checkLoginStatus: function() {
    const app = getApp();
    this.setData({
      isLogin: app.globalData.isLogin,
      userInfo: app.globalData.userInfo
    });
  },

  // 跳转到登录页面
  goToLogin: function() {
    wx.navigateTo({
      url: '/pages/login/login'
    });
  },

  // 跳转到注册页面
  goToRegister: function() {
    wx.navigateTo({
      url: '/pages/register/register'
    });
  },
  
  // 搜索框输入处理
  onSearchInput: function(e) {
    this.setData({
      searchKeyword: e.detail.value
    });
  },
  
  // 执行搜索
  performSearch: function() {
    const keyword = this.data.searchKeyword.trim();
    const category = this.data.selectedCategory;
    
    if (!keyword && !category) {
      wx.showToast({
        title: '请输入搜索关键词或选择分类',
        icon: 'none'
      });
      return;
    }
    
    this.setData({
      isSearching: true,
      hasSearched: true
    });
    
    // 模拟搜索请求延迟
    setTimeout(() => {
      // 在实际应用中，这里应该调用API进行搜索
      // 这里使用模拟数据
      this.searchProducts(keyword, category);
      
      this.setData({
        isSearching: false
      });
    }, 500);
  },
  
  // 新增：更改排序模式并对当前结果重新排序
  changeSortMode: function(e) {
    const mode = e.currentTarget.dataset.mode;
    if (!mode || mode === this.data.sortMode) return;
    this.setData({ sortMode: mode });
    if (this.data.searchResults && this.data.searchResults.length) {
      const sorted = this.sortResults(this.data.searchResults, mode);
      this.setData({ searchResults: sorted });
    }
  },

  // 新增：统一排序逻辑
  sortResults: function(results, mode) {
    const copy = results.slice();
    if (mode === 'price') {
      copy.sort((a, b) => a.price - b.price); // 价格升序
    } else {
      copy.sort((a, b) => b.heat - a.heat); // 热度降序
    }
    return copy;
  },
  
  // 执行搜索时可以调用此方法连接实际API
  searchProducts: function(keyword, category) {
    // 在实际应用中，这里应该调用API进行搜索
    // 目前使用模拟数据并根据关键词与分类过滤
    const list = this.data.mockProducts || [];
    const kw = (keyword || '').toLowerCase();
    const filtered = list.filter(item => {
      const byKw = kw ? (item.name.toLowerCase().includes(kw) || item.description.toLowerCase().includes(kw)) : true;
      const byCat = category ? item.category === category : true;
      return byKw && byCat;
    });
    const sorted = this.sortResults(filtered, this.data.sortMode);
    this.setData({
      searchResults: sorted
    });
  },
  
  // 切换分类下拉菜单
  toggleCategoryMenu: function() {
    this.setData({
      categoryMenuOpen: !this.data.categoryMenuOpen
    });
  },

  // 选择分类
  selectCategory: function(e) {
    const categoryId = e.currentTarget.dataset.id;
    this.setData({
      selectedCategory: categoryId,
      categoryMenuOpen: false
    });
    // 重新搜索
    this.performSearch();
  },
  
  // 查看商品详情
  viewProductDetail: function(e) {
    const productId = e.currentTarget.dataset.id;
    // 在实际应用中，这里应该跳转到商品详情页
    wx.showToast({
      title: `查看商品ID: ${productId}`,
      icon: 'none'
    });
    
    // 这里可以添加跳转到商品详情页的逻辑
    // wx.navigateTo({
    //   url: `/pages/productDetail/productDetail?id=${productId}`
    // });
  },
  
  // 跳转到发布页面
  goToPublish: function() {
    if (!this.data.isLogin) {
      wx.showToast({
        title: '请先登录',
        icon: 'none'
      });
      return;
    }
    
    wx.switchTab({
      url: '/pages/publish/publish'
    });
  }
});